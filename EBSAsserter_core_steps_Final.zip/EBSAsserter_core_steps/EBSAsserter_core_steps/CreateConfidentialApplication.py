
"""Written for creating a confidential application for EBS in IDCS"""

import json
import requests
import base64
import urllib3
from zipfile import ZipFile
import shutil
from pathlib import Path
urllib3.disable_warnings()
requests.packages.urllib3.util.ssl_ = 'ALL:@SECLEVEL=1'

class IAM():

    #import config files
    def __init__(self):
        config = json.load(open('config.json'))
        global idcsURL
        global clientID
        global clientSecret

        idcsURL = config["iamurl"]
        clientID = config["client_id"]
        clientSecret = config["client_secret"]

    #encode client & secret
    def get_encoded(self,clid, clsecret):    #6.
        encoded = clid + ":" + clsecret
        baseencoded = base64.urlsafe_b64encode(encoded.encode('UTF-8')).decode('ascii')
        return baseencoded

    #get access token
    def get_access_token(self,url, header):    #8.
        para = "grant_type=client_credentials&scope=urn:opc:idm:__myscopes__"
        response = requests.post(url, headers=header, data=para, verify=False)
        jsonresp = json.loads(response.content)
        access_token = jsonresp.get('access_token')
        return access_token

    #print access token
    def printaccesstoken(self):  #4.
        obj = IAM()
        encodedtoken = obj.get_encoded(clientID, clientSecret)     #5.
        extra = "/oauth2/v1/token"
        headers = {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                   'Authorization': 'Basic %s' % encodedtoken, 'Accept': '*/*'}
        accesstoken = obj.get_access_token(idcsURL + extra, headers)     #7.
        return accesstoken

    # Create a confidential application
    def createapplication(self):
        obj = IAM()
        accesstoken = obj.printaccesstoken()
        extra = "/admin/v1/Apps"
        headers = {'Accept': '*/*', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + accesstoken}
        para = json.dumps({
            "schemas": ["urn:ietf:params:scim:schemas:oracle:idcs:App"],
            "basedOnTemplate": {"value": "CustomWebAppTemplateId"},
            "displayName": "a1",
            "description": "Confidential client application for testing purposes",
            "clientType": "confidential",
            "isOAuthClient": True,
            "allowedGrants": ["authorization_code", "client_credentials"],
            "landingPageUrl": "https://ebsasserter.example.com:7004/dev",
            "active": True,
            "grantedAppRoles": ["Identity Domain Administrator"],
            "redirectUris": ["https://ebsasserter.example.com:7004/dev/response"],
            "logoutUri": "https://ebsasserter.example.com:7004/dev/logout",
            "postLogoutRedirectUris": ["https://ebsasserter.example.com:7004/dev"]

        })
        resp = requests.post(idcsURL+extra, headers=headers, verify=False, data=para)
        jsonresp = json.loads(resp.content)
        clID = jsonresp.get("name")
        clSecret = jsonresp.get("clientSecret")
        appID = jsonresp.get("id")


        extra1 = "/admin/v1/AppRoles"
        headers1 = {'Accept': '*/*', 'Authorization': 'Bearer ' + accesstoken}
        response = requests.request("GET", idcsURL+extra1, headers=headers1)
        jsonresp1 = json.loads(response.content)
        tempjsn = jsonresp1.get("Resources")
        for x in tempjsn:
            displayName = x.get("displayName")
            if displayName == "Authenticator Client":
                approleID1 = x.get("id")
        for x in tempjsn:
            displayName = x.get("displayName")
            if displayName == "Me":
                approleID2 = x.get("id")

        extra2 = "/admin/v1/Grants"
        payload = json.dumps({
            "grantee": {
                "type": "App",
                "value": appID
            },
            "app": {
                "value": "IDCSAppId"
            },
            "entitlement": {
                "attributeName": "appRoles",
                "attributeValue": approleID1
            },
            "grantMechanism": "ADMINISTRATOR_TO_APP",
            "schemas": [
                "urn:ietf:params:scim:schemas:oracle:idcs:Grant"
            ]
        })

        payload2 = json.dumps({
            "grantee": {
                "type": "App",
                "value": appID
            },
            "app": {
                "value": "IDCSAppId"
            },
            "entitlement": {
                "attributeName": "appRoles",
                "attributeValue": approleID2
            },
            "grantMechanism": "ADMINISTRATOR_TO_APP",
            "schemas": [
                "urn:ietf:params:scim:schemas:oracle:idcs:Grant"
            ]
        })
        print(payload)
        headers2 = {'Accept': '*/*', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + accesstoken}
        print(headers2)
        response1 = requests.request("POST", idcsURL+extra2, headers=headers2, data=payload)
        response2 = requests.request("POST", idcsURL + extra2, headers=headers2, data=payload2)
        print(response1.content)
        print(response2.content)
        return clID, clSecret, appID

obj = IAM()   #create an object
print(obj.createapplication())



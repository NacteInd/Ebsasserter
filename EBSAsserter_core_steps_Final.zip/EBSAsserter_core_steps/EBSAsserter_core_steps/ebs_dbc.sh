#! /bin/bash
sudo yum install jdk-11.x86_64 -y
sudo yum install unzip -y
sudo mkdir -p /opt/ebssdk/
sudo chmod -R 777 /opt/ebssdk
curl -o EBSAssert.zip --url $(sudo python3 EBSAsserterBinaryDownload.py) --header "Authorization: Bearer $(sudo python3 Access_Token_configFilejson.py)"
chmod 755 EBSAssert.zip
sudo -i -u oracle bash << EOF
cd /opt/ebssdk
unzip -o /home/opc/EBSAssert.zip
cd build/libs
unzip -o ebs.war
cd /opt/ebssdk/build/libs/WEB-INF/lib/
echo $PWD
#Copy jar file to working folder and to domain folder
cp /opt/ebssdk/build/libs/WEB-INF/lib/fndext* /opt/ebssdk/fndext.jar
# locate ebs env file and set the environment
#export JAVA_HOME=/usr/java/jdk1.7.0_201
#export WL_HOME=/u01/oracle/wlserver
printf "r" | source /u01/install/APPS/EBSapps.env
cd /opt/ebssdk

#create a dbc file
cp /u01/install/APPS/fs1/EBSapps/comn/clone/jlib/ojdbc6.jar /opt/ebssdk/ojdbc6.jar
export CLASSPATH=/opt/ebssdk/fndext.jar:/opt/ebssdk/ojdbc6.jar
echo pwd $PWD $CLASSPATH
java oracle.apps.fnd.security.AdminDesktop apps/apps CREATE NODE_NAME=ebsasserter.example.com DBC=/u01/install/APPS/fs1/inst/apps/ebsdb_apps/appl/fnd/12.0.0/secure/ebsdb.dbc
grep -Po '(?<=^APPL_SERVER_ID=)\w*$' ebsdb_EBSASSERTER.EXAMPLE.COM.dbc >>APPL_SERVER_ID.txt
EOF

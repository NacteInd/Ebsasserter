#! /bin/bash
sudo /u01/install/scripts/updatehosts.sh
#sudo hostname apps.example.com
sudo -i -u oracle bash << EOF
echo "In"
whoami
/u01/install/APPS/scripts/startdb.sh
. /u01/install/APPS/EBSapps.env run
mkdir -p ~/logs
cd  ~/logs
printf "sysadmin@1234\nsysadmin@1234\napps" | sh /u01/install/APPS/scripts/enableSYSADMIN.sh
cd ~/logs
printf "DemoPass@1234\nDemoPass@1234" | sh /u01/install/APPS/scripts/enableDEMOusers.sh
printf "http\ndemoebs\nexample.com\n8000\nebsdb\napps" | sh /u01/install/scripts/configwebentry.sh
/u01/install/APPS/scripts/startapps.sh
EOF
echo "Out"
whoami